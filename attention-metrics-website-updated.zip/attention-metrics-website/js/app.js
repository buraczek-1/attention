// Main application JavaScript
class AttentionMetricsApp {
    constructor() {
        this.currentLanguage = 'pl';
        this.currentTab = 'report';
        this.init();
    }

    init() {
        this.setupEventListeners();
        this.loadContent();
        this.generateTableOfContents();
        this.setupScrollSpy();
        this.setupResponsiveFeatures();
    }

    setupEventListeners() {
        // Language switcher
        document.querySelectorAll('.lang-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                this.switchLanguage(e.target.dataset.lang);
            });
        });

        // Tab switcher
        document.querySelectorAll('.nav-tab').forEach(tab => {
            tab.addEventListener('click', (e) => {
                this.switchTab(e.target.closest('.nav-tab').dataset.tab);
            });
        });

        // TOC toggle for mobile
        const tocToggle = document.getElementById('tocToggle');
        if (tocToggle) {
            tocToggle.addEventListener('click', () => {
                this.toggleTOC();
            });
        }

        // Smooth scrolling for TOC links
        document.addEventListener('click', (e) => {
            if (e.target.matches('.toc-link')) {
                e.preventDefault();
                const targetId = e.target.getAttribute('href').substring(1);
                this.scrollToSection(targetId);
            }
        });

        // Close mobile TOC when clicking outside
        document.addEventListener('click', (e) => {
            const tocSidebar = document.getElementById('tocSidebar');
            const tocNav = document.getElementById('tocNav');
            if (window.innerWidth <= 1024 && tocNav.classList.contains('open') && 
                !tocSidebar.contains(e.target)) {
                tocNav.classList.remove('open');
            }
        });

        // Handle window resize
        window.addEventListener('resize', () => {
            this.handleResize();
        });
    }

    switchLanguage(lang) {
        if (lang === this.currentLanguage) return;

        this.currentLanguage = lang;
        
        // Update language buttons
        document.querySelectorAll('.lang-btn').forEach(btn => {
            btn.classList.toggle('active', btn.dataset.lang === lang);
        });

        // Update HTML lang attribute
        document.documentElement.lang = lang;

        // Update all translatable elements
        this.updateTranslatableElements();
        
        // Reload content
        this.loadContent();
        
        // Regenerate TOC
        this.generateTableOfContents();
    }

    updateTranslatableElements() {
        document.querySelectorAll('[data-pl][data-en]').forEach(element => {
            const text = element.dataset[this.currentLanguage];
            if (text) {
                element.textContent = text;
            }
        });
    }

    switchTab(tab) {
        if (tab === this.currentTab) return;

        this.currentTab = tab;

        // Update tab buttons
        document.querySelectorAll('.nav-tab').forEach(tabBtn => {
            tabBtn.classList.toggle('active', tabBtn.dataset.tab === tab);
        });

        // Update tab content
        document.querySelectorAll('.tab-content').forEach(content => {
            content.classList.toggle('active', content.id === tab);
        });

        // Regenerate TOC for new tab
        this.generateTableOfContents();

        // Scroll to top
        window.scrollTo({ top: 0, behavior: 'smooth' });
    }

    loadContent() {
        const data = contentData[this.currentLanguage];
        
        if (this.currentTab === 'report') {
            this.loadReportContent(data.report);
        } else if (this.currentTab === 'summary') {
            this.loadSummaryContent(data.summary);
        }
    }

    loadReportContent(reportData) {
        const container = document.getElementById('reportSections');
        if (!container) return;

        container.innerHTML = reportData.sections.map(section => `
            <div class="content-section" id="${section.id}">
                <h2>${section.title}</h2>
                ${section.content}
            </div>
        `).join('');
    }

    loadSummaryContent(summaryData) {
        const container = document.getElementById('summarySections');
        if (!container) return;

        container.innerHTML = summaryData.sections.map(section => `
            <div class="content-section" id="${section.id}">
                <h2>${section.title}</h2>
                ${section.content}
            </div>
        `).join('');
    }

    generateTableOfContents() {
        const tocNav = document.getElementById('tocNav');
        if (!tocNav) return;

        const activeTabContent = document.querySelector('.tab-content.active');
        if (!activeTabContent) return;

        const headings = activeTabContent.querySelectorAll('h2, h3, h4');
        
        if (headings.length === 0) {
            tocNav.innerHTML = '<p>No sections available</p>';
            return;
        }

        const tocHTML = this.buildTOCHTML(headings);
        tocNav.innerHTML = tocHTML;
    }

    buildTOCHTML(headings) {
        let html = '<ul>';
        
        Array.from(headings).forEach(heading => {
            const level = parseInt(heading.tagName.substring(1));
            const id = heading.closest('.content-section')?.id || this.generateId(heading.textContent);
            const text = heading.textContent.trim();
            const levelClass = level > 2 ? `toc-level-${level}` : '';
            
            html += `
                <li class="${levelClass}">
                    <a href="#${id}" class="toc-link">${text}</a>
                </li>
            `;
        });
        
        html += '</ul>';
        return html;
    }

    generateId(text) {
        return text.toLowerCase()
            .replace(/[^\w\s-]/g, '')
            .replace(/\s+/g, '-')
            .substring(0, 50);
    }

    setupScrollSpy() {
        let ticking = false;

        const updateActiveSection = () => {
            const sections = document.querySelectorAll('.content-section');
            const tocLinks = document.querySelectorAll('.toc-link');
            
            let activeSection = null;
            const scrollPosition = window.scrollY + 150;

            sections.forEach(section => {
                const top = section.offsetTop;
                const bottom = top + section.offsetHeight;
                
                if (scrollPosition >= top && scrollPosition < bottom) {
                    activeSection = section;
                }
            });

            // Update active TOC link
            tocLinks.forEach(link => {
                const targetId = link.getAttribute('href').substring(1);
                const isActive = activeSection && activeSection.id === targetId;
                link.classList.toggle('active', isActive);
            });

            ticking = false;
        };

        const onScroll = () => {
            if (!ticking) {
                requestAnimationFrame(updateActiveSection);
                ticking = true;
            }
        };

        window.addEventListener('scroll', onScroll);
        
        // Initial call
        updateActiveSection();
    }

    scrollToSection(sectionId) {
        const section = document.getElementById(sectionId);
        if (section) {
            const headerHeight = 120; // Account for sticky header
            const targetPosition = section.offsetTop - headerHeight;
            
            window.scrollTo({
                top: targetPosition,
                behavior: 'smooth'
            });
        }
    }

    toggleTOC() {
        const tocNav = document.getElementById('tocNav');
        if (tocNav) {
            tocNav.classList.toggle('open');
        }
    }

    setupResponsiveFeatures() {
        this.handleResize();
    }

    handleResize() {
        const tocNav = document.getElementById('tocNav');
        
        if (window.innerWidth > 1024) {
            // Desktop: always show TOC
            if (tocNav) {
                tocNav.classList.remove('open');
                tocNav.style.display = 'block';
            }
        } else {
            // Mobile/Tablet: hide TOC by default
            if (tocNav && !tocNav.classList.contains('open')) {
                tocNav.style.display = 'none';
            }
        }
    }

    // Utility methods
    debounce(func, wait) {
        let timeout;
        return function executedFunction(...args) {
            const later = () => {
                clearTimeout(timeout);
                func(...args);
            };
            clearTimeout(timeout);
            timeout = setTimeout(later, wait);
        };
    }

    // Print functionality
    setupPrintStyles() {
        const printButton = document.createElement('button');
        printButton.textContent = this.currentLanguage === 'pl' ? 'Drukuj' : 'Print';
        printButton.className = 'print-btn';
        printButton.addEventListener('click', () => {
            window.print();
        });
        
        // Add print button to header if needed
        const headerControls = document.querySelector('.header-controls');
        if (headerControls && !headerControls.querySelector('.print-btn')) {
            headerControls.appendChild(printButton);
        }
    }

    // Search functionality (basic)
    setupSearch() {
        const searchInput = document.createElement('input');
        searchInput.type = 'text';
        searchInput.placeholder = this.currentLanguage === 'pl' ? 'Szukaj...' : 'Search...';
        searchInput.className = 'search-input';
        
        const debouncedSearch = this.debounce((query) => {
            this.performSearch(query);
        }, 300);
        
        searchInput.addEventListener('input', (e) => {
            debouncedSearch(e.target.value);
        });
        
        return searchInput;
    }

    performSearch(query) {
        if (!query.trim()) {
            this.clearSearchHighlights();
            return;
        }

        const content = document.querySelector('.tab-content.active');
        if (!content) return;

        this.clearSearchHighlights();
        
        const regex = new RegExp(`(${query})`, 'gi');
        const walker = document.createTreeWalker(
            content,
            NodeFilter.SHOW_TEXT,
            null,
            false
        );

        const textNodes = [];
        let node;
        while (node = walker.nextNode()) {
            if (node.textContent.trim() && regex.test(node.textContent)) {
                textNodes.push(node);
            }
        }

        textNodes.forEach(textNode => {
            const parent = textNode.parentNode;
            const highlightedHTML = textNode.textContent.replace(regex, '<mark class="search-highlight">$1</mark>');
            const wrapper = document.createElement('span');
            wrapper.innerHTML = highlightedHTML;
            parent.replaceChild(wrapper, textNode);
        });
    }

    clearSearchHighlights() {
        document.querySelectorAll('.search-highlight').forEach(highlight => {
            const parent = highlight.parentNode;
            parent.replaceChild(document.createTextNode(highlight.textContent), highlight);
            parent.normalize();
        });
    }

    // Analytics tracking (placeholder)
    trackEvent(category, action, label) {
        // Placeholder for analytics tracking
        console.log('Analytics:', { category, action, label });
    }

    // Accessibility improvements
    setupAccessibility() {
        // Add skip link
        const skipLink = document.createElement('a');
        skipLink.href = '#main';
        skipLink.textContent = this.currentLanguage === 'pl' ? 'Przejdź do treści' : 'Skip to content';
        skipLink.className = 'skip-link';
        document.body.insertBefore(skipLink, document.body.firstChild);

        // Add ARIA labels
        document.querySelectorAll('.nav-tab').forEach(tab => {
            tab.setAttribute('role', 'tab');
            tab.setAttribute('aria-selected', tab.classList.contains('active'));
        });

        // Add focus management
        document.addEventListener('keydown', (e) => {
            if (e.key === 'Escape') {
                const tocNav = document.getElementById('tocNav');
                if (tocNav && tocNav.classList.contains('open')) {
                    this.toggleTOC();
                }
            }
        });
    }
}

// Initialize the application when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    const app = new AttentionMetricsApp();
    
    // Make app globally available for debugging
    window.attentionMetricsApp = app;
    
    // Setup additional features
    app.setupAccessibility();
    
    // Track page load
    app.trackEvent('Page', 'Load', 'Attention Metrics Research');
});

// Service Worker registration for offline functionality (optional)
if ('serviceWorker' in navigator) {
    window.addEventListener('load', () => {
        navigator.serviceWorker.register('/sw.js')
            .then(registration => {
                console.log('SW registered: ', registration);
            })
            .catch(registrationError => {
                console.log('SW registration failed: ', registrationError);
            });
    });
}

// Export for module systems
if (typeof module !== 'undefined' && module.exports) {
    module.exports = AttentionMetricsApp;
}

