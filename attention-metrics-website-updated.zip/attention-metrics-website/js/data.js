// Content data for both languages
const contentData = {
    pl: {
        report: {
            sections: [
                {
                    id: "wprowadzenie-i-tlo",
                    title: "Wprowadzenie i tło",
                    content: `
                        <p>Ekosystem reklamy cyfrowej osiągnął krytyczny punkt zwrotny, w którym tradycyjne podejścia pomiarowe okazują się nieadekwatne do uchwycenia prawdziwej wartości i wpływu inwestycji reklamowych. Przez dziesięciolecia branża polegała na metrykach takich jak wyświetlenia, współczynniki klikalności i przeglądalność jako zastępczych wskaźnikach skuteczności reklamy.</p>
                        
                        <p>Koncepcja uwagi w reklamie nie jest nowa. Tradycyjne planowanie mediów od dawna uznawało znaczenie przyciągania i utrzymywania uwagi konsumentów, a skupienie reklamy telewizyjnej na zasięgu i częstotliwości służyło jako wczesne próby kwantyfikacji uwagi na skalę. Jednak rewolucja cyfrowa wprowadziła nowe złożoności i możliwości pomiaru, do których tradycyjne metryki nie były zaprojektowane.</p>
                        
                        <p>Metryki uwagi reprezentują fundamentalną zmianę w podejściu branży reklamowej do pomiaru i optymalizacji. Zamiast skupiać się wyłącznie na dostawie i podstawowych wskaźnikach zaangażowania, metryki uwagi próbują kwantyfikować poznawcze i emocjonalne zaangażowanie, które występuje, gdy konsumenci spotykają treści reklamowe.</p>
                        
                        <p>Krajobraz płatnych mediów społecznościowych przedstawia szczególnie przekonujące możliwości pomiaru uwagi. Platformy takie jak Facebook, Instagram, TikTok, YouTube, Pinterest, Snapchat, X i Reddit stworzyły immersyjne, bogate w treści środowiska, w których konsumenci aktywnie angażują się z mediami w sposób, który generuje bogate sygnały behawioralne.</p>
                    `
                },
                {
                    id: "definiowanie-metryk-uwagi",
                    title: "Definiowanie metryk uwagi",
                    content: `
                        <p>Metryki uwagi reprezentują wyrafinowaną ewolucję w pomiarze reklamy, która wykracza poza tradycyjne wskaźniki oparte na ekspozycji, aby kwantyfikować poznawcze i emocjonalne zaangażowanie konsumentów z treściami reklamowymi.</p>
                        
                        <h3>Podstawowe komponenty metryk uwagi</h3>
                        <p>Metryki uwagi są zbudowane na kilku fundamentalnych komponentach:</p>
                        <ul>
                            <li><strong>Pomiar ekspozycji</strong> - wykracza poza tradycyjne standardy przeglądalności</li>
                            <li><strong>Kwantyfikacja zaangażowania</strong> - mierzy aktywne zachowania i interakcje</li>
                            <li><strong>Analiza czasowa</strong> - uwaga jako dynamiczny proces rozwijający się w czasie</li>
                        </ul>
                        
                        <h3>Specyficzne metryki uwagi</h3>
                        <ul>
                            <li><strong>Attentive Cost Per Mille (aCPM)</strong> - koszt dotarcia do 1000 aktywnie uważnych konsumentów</li>
                            <li><strong>Attention Per Mille (APM)</strong> - całkowita uwaga wygenerowana na 1000 wyświetleń</li>
                            <li><strong>Effective Attention Per Mille (eAPM)</strong> - uwaga zgodna z celami kampanii</li>
                            <li><strong>Adelaide Attention Unit (AU)</strong> - wynik 1-100 przewidujący wyniki biznesowe</li>
                        </ul>
                    `
                },
                {
                    id: "metody-i-technologie-pomiaru",
                    title: "Metody i technologie pomiaru",
                    content: `
                        <p>Infrastruktura techniczna leżąca u podstaw pomiaru uwagi reprezentuje jeden z najbardziej wyrafinowanych rozwojów w technologii reklamy cyfrowej, łącząc zaawansowane metody zbierania danych, analitykę w czasie rzeczywistym i algorytmy uczenia maszynowego.</p>
                        
                        <h3>Technologie oparte na JavaScript</h3>
                        <p>Tagi JavaScript reprezentują najszerzej wdrażaną technologię pomiaru uwagi w środowiskach reklamowych opartych na sieci web. Te lekkie fragmenty kodu są osadzone w treściach reklamowych lub obok nich, umożliwiając zbieranie danych w czasie rzeczywistym.</p>
                        
                        <h3>Wdrażanie mobile SDK</h3>
                        <p>Open Measurement SDK (OM SDK) wyłonił się jako standard branżowy dla pomiaru uwagi w środowiskach aplikacji mobilnych, rozwiązując unikalne wyzwania i możliwości przedstawiane przez reklamę mobilną.</p>
                        
                        <h3>Pomiar biometryczny i fizjologiczny</h3>
                        <ul>
                            <li><strong>Śledzenie ruchu oczu</strong> - złoty standard pomiaru uwagi wizualnej</li>
                            <li><strong>Monitorowanie biometryczne</strong> - tętno, GSR, analiza ekspresji twarzy</li>
                            <li><strong>EEG</strong> - bezpośrednie wglądy w aktywność mózgu</li>
                        </ul>
                        
                        <h3>Uczenie maszynowe i AI</h3>
                        <p>Zastosowanie technologii uczenia maszynowego i sztucznej inteligencji przekształciło pomiar uwagi z dyscypliny głównie opisowej w predykcyjną i preskryptywną.</p>
                    `
                }
            ]
        },
        summary: {
            sections: [
                {
                    id: "kluczowe-definicje",
                    title: "Kluczowe definicje i koncepcje",
                    content: `
                        <div class="summary-card">
                            <h3>Metryki uwagi</h3>
                            <p>Mierzą poznawcze i emocjonalne zaangażowanie konsumentów z treściami reklamowymi, wykraczając poza tradycyjne wskaźniki oparte na ekspozycji, aby kwantyfikować, czy reklamy są rzeczywiście zauważane, przetwarzane i zapamiętywane.</p>
                        </div>
                        
                        <div class="summary-card">
                            <h3>Podstawowe metryki</h3>
                            <ul>
                                <li><strong>Attention Unit (AU):</strong> Wynik Adelaide 1-100 przewidujący wyniki biznesowe</li>
                                <li><strong>Attentive Cost Per Mille (aCPM):</strong> Koszt dotarcia do 1000 aktywnie uważnych konsumentów</li>
                                <li><strong>Attention Per Mille (APM):</strong> Całkowita uwaga wygenerowana na 1000 wyświetleń</li>
                                <li><strong>Effective Attention Per Mille (eAPM):</strong> Uwaga zgodna z celami kampanii</li>
                            </ul>
                        </div>
                    `
                },
                {
                    id: "dlaczego-metryki-uwagi-maja-znaczenie",
                    title: "Dlaczego metryki uwagi mają znaczenie",
                    content: `
                        <div class="summary-card">
                            <h3>Lepszy wpływ biznesowy</h3>
                            <ul>
                                <li>Średnio o <strong>41% wyższy wzrost marki</strong></li>
                                <li>O <strong>55% silniejszy wpływ na dolną część lejka</strong></li>
                                <li>Lepsza korelacja z wynikami biznesowymi niż tradycyjne metryki</li>
                            </ul>
                        </div>
                        
                        <div class="summary-card">
                            <h3>Kluczowe zalety nad tradycyjnymi metrykami</h3>
                            <ul>
                                <li>Pomiar skoncentrowany na jakości vs. ilości</li>
                                <li>Wrażliwość kontekstowa (urządzenie, umiejscowienie, środowisko)</li>
                                <li>Granularność czasowa (ewolucja uwagi w czasie)</li>
                                <li>Porównywalność międzyplatformowa</li>
                                <li>Możliwości optymalizacji w czasie rzeczywistym</li>
                            </ul>
                        </div>
                    `
                },
                {
                    id: "adopcja-rynkowa-2024-2025",
                    title: "Adopcja rynkowa (2024-2025)",
                    content: `
                        <div class="summary-card">
                            <h3>Obecne statystyki</h3>
                            <ul>
                                <li><strong>47%</strong> decydentów po stronie kupującej oczekiwało większego skupienia na metrykach uwagi w 2024</li>
                                <li><strong>36%</strong> amerykańskich kupujących reklamy priorytetowo traktuje metryki uwagi</li>
                                <li><strong>84%</strong> reklamodawców łączy metryki uwagi z wynikami biznesowymi</li>
                                <li><strong>73%</strong> priorytetowo traktuje wydajność mediów przy ocenie metryk uwagi</li>
                            </ul>
                        </div>
                        
                        <div class="summary-card">
                            <h3>Liderzy branżowi</h3>
                            <ul>
                                <li>CPG, Motoryzacja, Usługi Finansowe wykazują najwyższą adopcję</li>
                                <li>Ameryka Północna prowadzi globalnie we wdrażaniu</li>
                                <li>Adopcja w agencjach przyspiesza w głównych holdingach</li>
                            </ul>
                        </div>
                    `
                }
            ]
        }
    },
    en: {
        report: {
            sections: [
                {
                    id: "introduction-and-background",
                    title: "Introduction and background",
                    content: `
                        <p>The digital advertising ecosystem has reached a critical inflection point where traditional measurement approaches are proving inadequate for capturing the true value and impact of advertising investments. For decades, the industry has relied on metrics such as impressions, click-through rates, and viewability as proxies for advertising effectiveness.</p>
                        
                        <p>The concept of attention in advertising is not new. Traditional media planning has long recognized the importance of capturing and maintaining consumer attention, with television advertising's focus on reach and frequency serving as early attempts to quantify attention at scale. However, the digital revolution introduced new complexities and opportunities for measurement that traditional metrics were not designed to address.</p>
                        
                        <p>Attention metrics represent a fundamental shift in how the advertising industry approaches measurement and optimization. Rather than focusing solely on delivery and basic engagement indicators, attention metrics attempt to quantify the cognitive and emotional engagement that occurs when consumers encounter advertising content.</p>
                        
                        <p>The paid social media landscape presents particularly compelling opportunities for attention measurement. Platforms like Facebook, Instagram, TikTok, YouTube, Pinterest, Snapchat, X, and Reddit have created immersive, content-rich environments where consumers actively engage with media in ways that generate rich behavioral signals.</p>
                    `
                },
                {
                    id: "defining-attention-metrics",
                    title: "Defining attention metrics",
                    content: `
                        <p>Attention metrics represent a sophisticated evolution in advertising measurement that goes beyond traditional exposure-based indicators to quantify the cognitive and emotional engagement consumers have with advertising content.</p>
                        
                        <h3>Core components of attention metrics</h3>
                        <p>Attention metrics are built upon several foundational components:</p>
                        <ul>
                            <li><strong>Exposure measurement</strong> - goes beyond traditional viewability standards</li>
                            <li><strong>Engagement quantification</strong> - measures active behaviors and interactions</li>
                            <li><strong>Temporal analysis</strong> - attention as a dynamic process that unfolds over time</li>
                        </ul>
                        
                        <h3>Specific attention metrics</h3>
                        <ul>
                            <li><strong>Attentive Cost Per Mille (aCPM)</strong> - cost of reaching 1,000 actively attentive consumers</li>
                            <li><strong>Attention Per Mille (APM)</strong> - total attention generated per 1,000 impressions</li>
                            <li><strong>Effective Attention Per Mille (eAPM)</strong> - attention aligned with campaign objectives</li>
                            <li><strong>Adelaide Attention Unit (AU)</strong> - 1-100 score predicting business outcomes</li>
                        </ul>
                    `
                },
                {
                    id: "measurement-methods-and-technologies",
                    title: "Measurement methods and technologies",
                    content: `
                        <p>The technical infrastructure underlying attention measurement represents one of the most sophisticated developments in digital advertising technology, combining advanced data collection methods, real-time analytics, and machine learning algorithms.</p>
                        
                        <h3>JavaScript-based measurement technologies</h3>
                        <p>JavaScript tags represent the most widely deployed technology for attention measurement in web-based advertising environments. These lightweight code snippets enable real-time data collection about user interactions and environmental factors.</p>
                        
                        <h3>Mobile SDK implementation</h3>
                        <p>The Open Measurement SDK (OM SDK) has emerged as the industry standard for attention measurement in mobile application environments, addressing unique challenges and opportunities presented by mobile advertising.</p>
                        
                        <h3>Biometric and physiological measurement</h3>
                        <ul>
                            <li><strong>Eye-tracking technology</strong> - gold standard for measuring visual attention</li>
                            <li><strong>Biometric monitoring</strong> - heart rate, GSR, facial expression analysis</li>
                            <li><strong>EEG</strong> - direct insights into brain activity</li>
                        </ul>
                        
                        <h3>Machine learning and AI</h3>
                        <p>The application of machine learning and artificial intelligence technologies has transformed attention measurement from a primarily descriptive discipline to a predictive and prescriptive one.</p>
                    `
                }
            ]
        },
        summary: {
            sections: [
                {
                    id: "key-definitions",
                    title: "Key definitions & concepts",
                    content: `
                        <div class="summary-card">
                            <h3>Attention metrics</h3>
                            <p>Measure the cognitive and emotional engagement consumers have with advertising content, going beyond traditional exposure-based indicators to quantify whether ads are truly noticed, processed, and retained.</p>
                        </div>
                        
                        <div class="summary-card">
                            <h3>Core metrics</h3>
                            <ul>
                                <li><strong>Attention Unit (AU):</strong> Adelaide's 1-100 score predicting business outcomes</li>
                                <li><strong>Attentive Cost Per Mille (aCPM):</strong> Cost of reaching 1,000 actively attentive consumers</li>
                                <li><strong>Attention Per Mille (APM):</strong> Total attention generated per 1,000 impressions</li>
                                <li><strong>Effective Attention Per Mille (eAPM):</strong> Attention aligned with campaign objectives</li>
                            </ul>
                        </div>
                    `
                },
                {
                    id: "why-attention-metrics-matter",
                    title: "Why attention metrics matter",
                    content: `
                        <div class="summary-card">
                            <h3>Superior business impact</h3>
                            <ul>
                                <li><strong>41% higher brand lift</strong> on average</li>
                                <li><strong>55% stronger lower-funnel impact</strong></li>
                                <li>Better correlation with business outcomes than traditional metrics</li>
                            </ul>
                        </div>
                        
                        <div class="summary-card">
                            <h3>Key advantages over traditional metrics</h3>
                            <ul>
                                <li>Quality-focused vs. quantity-focused measurement</li>
                                <li>Contextual sensitivity (device, placement, environment)</li>
                                <li>Temporal granularity (attention evolution over time)</li>
                                <li>Cross-platform comparability</li>
                                <li>Real-time optimization capabilities</li>
                            </ul>
                        </div>
                    `
                }
            ]
        }
    }
};

